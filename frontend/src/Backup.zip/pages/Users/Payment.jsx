import React from 'react';

function Header() {
  return (
      <div id="header">
          <div>
              <ul className="navigation">
                  <li>
                      <a href="Home">Home</a>
                  </li>
                  <li>
                      <a href="About">About</a>
                  </li>
                  <li>
                      <a href="Menu">Menu</a>
                  </li>
                  <li>
                      <a className="active" href="Payment">Payment</a>
                  </li>
              </ul>
          </div>
      </div>
  );
}

function ShoppingCart() {
  return (
      <div className="shopping-cart">
          {/* Add shopping cart items here */}
      </div>
  );
}

function CheckoutForm() {
    return (
        <div className="row">
            <div className="col-75">
                <div className="container">
                    <form action="/action_page.php">
                        <div className="row">
                            <div className="col-50">
                                <h3>Billing Address</h3>
                                <label htmlFor="fname"><i className="fa fa-user"></i> Full Name</label>
                                <input type="text" id="fname" name="firstname" placeholder="John M. Doe" />
                                <label htmlFor="email"><i className="fa fa-envelope"></i> Email</label>
                                <input type="text" id="email" name="email" placeholder="john@example.com" />
                                <label htmlFor="adr"><i className="fa fa-address-card-o"></i> Address</label>
                                <input type="text" id="adr" name="address" placeholder="542 W. 15th Street" />
                                <label htmlFor="city"><i className="fa fa-institution"></i> City</label>
                                <input type="text" id="city" name="city" placeholder="New York" />

                                <div className="row">
                                    <div className="col-50">
                                    </div>
                                    <div className="col-50">
                                    </div>
                                </div>
                            </div>

                            <div className="col-50">
                                <h3>Payment</h3>
                                
                                <div className="icon-container">
                                    <i className="fa fa-cc-visa" style={{color: 'navy'}}></i>
                                    <i className="fa fa-cc-amex" style={{color: 'blue'}}></i>
                                    <i className="fa fa-cc-mastercard" style={{color: 'red'}}></i>
                                    <i className="fa fa-cc-discover" style={{color: 'orange'}}></i>
                                </div>
                                <label htmlFor="cname">Name on Card</label>
                                <input type="text" id="cname" name="cardname" placeholder="John More Doe" />
                                <label htmlFor="ccnum">Credit card number</label>
                                <input type="text" id="ccnum" name="cardnumber" placeholder="1111-2222-3333-4444" />
                                <label htmlFor="expmonth">Exp Month</label>
                                <input type="text" id="expmonth" name="expmonth" placeholder="September" />
                                <div className="row">
                                    <div className="col-50">
                                        <label htmlFor="expyear">Exp Year</label>
                                        <input type="text" id="expyear" name="expyear" placeholder="2024" />
                                    </div>
                                    <div className="col-50">
                                        <label htmlFor="cvv">CVV</label>
                                        <input type="text" id="cvv" name="cvv" placeholder="352" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <label>
                            <input type="checkbox" checked="checked" name="sameadr" /> Shipping address same as billing
                        </label>
                        <br />
                        <input type="submit" value="Order Confirmation" className="btn" />
                    </form>
                </div>
            </div>
        </div>
    );
}

function CheckoutPage() {
    return (
        <div>
            <ShoppingCart />
            <h2>Responsive Checkout Form</h2>
            <CheckoutForm />
        </div>
    );
}

function App() {
  return (
      <div>
          <Header />
          <CheckoutPage />
      </div>
  );
}

export default App;
