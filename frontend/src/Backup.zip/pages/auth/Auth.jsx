import React, { useState } from 'react';

const AuthComponent = ({ setShowUsers }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isRegistered, setIsRegistered] = useState(false); // State to manage registration status

  const handleSubmit = async (event) => {
    event.preventDefault();

    const url = isLogin
      ? 'http://localhost:8090/api/login' // Update with your actual login endpoint
      : 'http://localhost:8090/api/signup'; // Update with your actual signup endpoint

    const payload = { user_name: username, password }; // Adjust payload based on your backend requirements

    try {
      console.log("Trying to send req");
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      const data = await response.json();
      console.log('Server response:', data);
      
      if (response.ok) {
        if (isLogin) {
          setShowUsers(data.access); // Assuming you want to show users after login
        } else {
          setIsRegistered(true); // Set state to indicate successful registration
        }
      } else {
        // Handle error
        alert(data.error || 'Request failed. Please try again.');
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const toggleAuthMode = () => {
    setIsLogin(!isLogin);
  };

  return (
    <div className="auth-container">
      <h2>{isLogin ? 'Login' : 'Sign Up'}</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="username">Username:</label>
          <input
            type="text"
            id="username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
          />
        </div>
        <div>
          <label htmlFor="password">Password:</label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        <button type="submit">{isLogin ? 'Login' : 'Sign Up'}</button>
      </form>
      <div>
        {isLogin ? 'First time here?' : 'Already have an account?'}
        <button onClick={toggleAuthMode}>
          {isLogin ? 'Sign Up' : 'Login'}
        </button>
      </div>
      {isRegistered && <p>Registration successful! Proceed to login.</p>}
    </div>
  );
};

export default AuthComponent;
