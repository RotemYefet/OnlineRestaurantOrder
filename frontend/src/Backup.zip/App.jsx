import { useEffect, useState } from "react";
import reactLogo from "./assets/react.svg";
import viteLogo from "/vite.svg";
import "./App.css";
import Users from "./pages/Users/Users";
import Home from "./pages/Users/Home";
import Menu from "./pages/Users/Menu";
import About from "./pages/Users/About";
import Payment from "./pages/Users/Payment";
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';

import AuthComponent from './pages/auth/Auth';
function App() {
  const [users, setUsers] = useState();
  const [showUsers, setShowUsers] = useState(false)

  useEffect(() => {
    const getUsersData = async () => {
      const response = await fetch("http://127.0.0.1:8090/api/users");
      const data = await response.json();
      setUsers(data.users);
    };
    getUsersData(users); // Call getUsersData without passing users
  }, []); // Empty dependency array ensures useEffect runs only once on mount

  console.log(users);
  return <>
          {!showUsers && <AuthComponent setShowUsers={setShowUsers}/>}
          {users && showUsers && <Users users={users}/>}
        </>
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Navigate to="/AuthComponent" replace />} />
        <Route path="/Home" element={<Home />} />
        <Route path="/About" element={<About />} />
        <Route path="/Menu" element={<Menu />} />
        <Route path="/Payment" element={<Payment />} />
        <Route path="/AuthComponent" element={<AuthComponent setShowUsers={setShowUsers} />} />
      </Routes>
    </Router>
  );
}

export default App;
